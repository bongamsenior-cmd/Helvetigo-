TEYUNAI index.html update

Contents:
- index.html: the supplied page structure with updated country pills and Spanish/Chinese
  language options prepared in the language menu.

Important compatibility note:
- The currently supplied app.js supports French, English, German, Italian and Japanese.
- Spanish and Chinese menu entries are intentionally disabled in this HTML until full
  `es` and `zh` translations and `languageMeta` entries are added to app.js.
- This package does not include or replace app.js or styles.css.
- The country pills reuse the existing `switzerland`, `france`, and `germany` keys.
- This is a development-branch update only; do not deploy to production before testing.
