(() => {
  "use strict";
  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];
  const year = $("#year"); if (year) year.textContent = new Date().getFullYear();

  // The analogue clock is a permanent part of the TEYUNAI brand composition.
  const clock = $(".teyunai-clock");
  if (clock) {
    const ticks = $(".teyunai-clock-ticks", clock);
    for (let i=0;i<60;i++) {
      const tick=document.createElement("span");
      if (i%5===0) tick.className="major";
      tick.style.transform=`translateX(-50%) rotate(${i*6}deg)`;
      ticks.append(tick);
    }
    const h=$(".ty-hour",clock),m=$(".ty-minute",clock),s=$(".ty-second",clock);
    const update=()=>{
      const d=new Date(),sec=d.getSeconds(),min=d.getMinutes(),hour=d.getHours()%12;
      h.style.transform=`translateX(-50%) rotate(${hour*30+min*.5}deg)`;
      m.style.transform=`translateX(-50%) rotate(${min*6+sec*.1}deg)`;
      s.style.transform=`translateX(-50%) rotate(${sec*6}deg)`;
    };
    update(); window.setInterval(update,1000);
  }



  const cities=[
    "Genève, Switzerland","Geneva Airport (GVA), Switzerland","Genève-Cornavin, Switzerland",
    "Lausanne, Switzerland","Zürich, Switzerland","Bern, Switzerland","Basel, Switzerland",
    "Paris, France","Lyon, France","Annecy, France","Chamonix, France","München, Germany",
    "Stuttgart, Germany","Milano, Italy","Torino, Italy","Barcelona, Spain","London, United Kingdom",
    "Amsterdam, Netherlands","Genova, Italy","Gent, Belgium","Vienna, Austria","Prague, Czechia",
    "Copenhagen, Denmark","Brussels, Belgium","Lisbon, Portugal","Rome, Italy","Florence, Italy"
  ];
  function autocomplete(input,origin){
    if(!input)return;
    const wrap=input.closest(".input-with-icon");wrap.classList.add("teyunai-autocomplete-wrap");
    const list=document.createElement("div");list.className="teyunai-city-suggestions";list.hidden=true;list.setAttribute("role","listbox");wrap.append(list);
    if(origin){
      const locate=document.createElement("button");locate.type="button";locate.className="teyunai-location-icon";locate.textContent="◎";locate.title="Use my current location";locate.setAttribute("aria-label","Use my current location");wrap.append(locate);
      locate.addEventListener("click",()=>{
        if(!navigator.geolocation)return;
        locate.disabled=true;
        navigator.geolocation.getCurrentPosition(async pos=>{
          const {latitude,longitude}=pos.coords;
          try{
            const url=`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${latitude}&lon=${longitude}`;
            const response=await fetch(url);if(!response.ok)throw Error();
            const data=await response.json(),a=data.address||{};
            input.value=[a.city||a.town||a.village||a.municipality,a.country].filter(Boolean).join(", ")||`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
          }catch{input.value=`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`}
          input.dispatchEvent(new Event("input",{bubbles:true}));locate.disabled=false;
        },()=>{locate.disabled=false},{timeout:10000,maximumAge:60000});
      });
    }
    let matches=[],active=-1;
    const close=()=>{list.hidden=true;active=-1};
    const choose=value=>{input.value=value;input.dispatchEvent(new Event("input",{bubbles:true}));close()};
    const draw=()=>{
      const q=input.value.trim().toLocaleLowerCase();
      if(q.length<2){close();return}
      matches=cities.filter(x=>x.toLocaleLowerCase().includes(q)).slice(0,6);
      list.replaceChildren();
      matches.forEach((value,i)=>{
        const b=document.createElement("button");b.type="button";b.className="teyunai-city-option";b.setAttribute("role","option");
        b.textContent=value;b.addEventListener("mousedown",e=>e.preventDefault());b.addEventListener("click",()=>choose(value));list.append(b);
      });
      list.hidden=!matches.length;
    };
    input.addEventListener("input",draw);input.addEventListener("focus",draw);
    input.addEventListener("keydown",e=>{
      if(list.hidden)return;
      if(e.key==="ArrowDown"){e.preventDefault();active=Math.min(active+1,matches.length-1)}
      else if(e.key==="ArrowUp"){e.preventDefault();active=Math.max(active-1,0)}
      else if(e.key==="Enter"&&active>=0){e.preventDefault();choose(matches[active])}
      else if(e.key==="Escape")close();
      $$(".teyunai-city-option",list).forEach((b,i)=>b.classList.toggle("active",i===active));
    });
    input.addEventListener("blur",()=>window.setTimeout(close,130));
  }
  autocomplete($("#from"),true);autocomplete($("#to"),false);
  $$(".provider").forEach(card=>card.classList.add("provider-ready"));
})();